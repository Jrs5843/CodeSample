DiscGolf folder contains the website, I used Visual Studio Code.

Data is the folder containing mongoDB.

If that does not work:
The database is called: DiscGolf
The collections are called: JoshBag, MarissaBag, and Stats

If I sent the incorrect files or you're unable to get it to run I provided screenshots of each page.