var express = require('express');
var router = express.Router();

/* GET home page */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/* GET Josh's Disc Bag page */
router.get('/DiscJosh', function(req, res) {
  var db = req.db;
  var collection = db.get('JoshBag');
  collection.find({},{},function(e,docs){
      res.render('DiscJosh', {
          "DiscJosh" : docs
      });
  });
});

/* GET Marissa's Disc Bag page */
router.get('/DiscMarissa', function(req, res) {
  var db = req.db;
  var collection = db.get('MarissaBag');
  collection.find({},{},function(e,docs){
      res.render('DiscMarissa', {
          "DiscMarissa" : docs
      });
  });
});

/* GET Stats Info page */
router.get('/Stats', function(req, res) {
  var db = req.db;
  var collection = db.get('Stats');
  collection.find({},{},function(e,docs){
      res.render('Stats', {
          "Stats" : docs
      });
  });
});

/* POST to Add Disc to Josh's Bag*/
router.post('/addDiscJosh', function(req, res) {
  // Set internal DB variable
  var db = req.db;
  // Get form values
  var discName = req.body.discName;
  var plastic = req.body.plastic;
  var type = req.body.type;
  var speed = req.body.speed;
  var glide = req.body.glide;
  var turn = req.body.turn;
  var fade = req.body.fade;
  var stability = req.body.stability;
  var brand = req.body.brand;
  // Set collection
  var collection = db.get('JoshBag');
  // Submit to the DB
  collection.insert({
      "DiscName" : discName,
      "Plastic" : plastic,
      "Type" : type,
      "Speed" : speed,
      "Glide" : glide,
      "Turn" : turn,
      "Fade" : fade,
      "Stability" : stability,
      "MVP" : brand
  }, function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem adding the information to the database.");
      }
      else {
          // And forward to same page to refresh and show disc
          res.redirect("DiscJosh");
      }
  });
});


/* POST to Add Disc to Marissa's Bag */
router.post('/addDiscMarissa', function(req, res) {
  // Set internal DB variable
  var db = req.db;
  // Get form values
  var discName = req.body.discName;
  var plastic = req.body.plastic;
  var type = req.body.type;
  var speed = req.body.speed;
  var glide = req.body.glide;
  var turn = req.body.turn;
  var fade = req.body.fade;
  var stability = req.body.stability;
  var brand = req.body.brand;
  // Set collection
  var collection = db.get('MarissaBag');
  // Submit to the DB
  collection.insert({
      "DiscName" : discName,
      "Plastic" : plastic,
      "Type" : type,
      "Speed" : speed,
      "Glide" : glide,
      "Turn" : turn,
      "Fade" : fade,
      "Stability" : stability,
      "MVP" : brand
  }, function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem adding the information to the database.");
      }
      else {
          // And forward to same page to refresh and show disc
          res.redirect("DiscMarissa");
      }
  });
});

module.exports = router;
